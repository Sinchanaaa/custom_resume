<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
<body>

    <div class="row no-gutters">


        <div class="col no-gutters">
            <h3>PERSONAL INFORMATION</h3>
            <div class="perinfo">
                <label for="name">NAME: </label>
                <input type="text" name="" id="name" placeholder="enter your name" class="form-control">
            </div>
            <div class="perinfo">
                <label for="phone">PHONE NO: </label>
                <input type="text" name="" id="phone no" placeholder="enter your phone no" class="form-control">
            </div>
            <div class="perinfo">
                <label for="address">ADDRESS: </label>
                <textarea type="text" name="" id="address" placeholder="enter your address" class="form-control"></textarea>
            </div>
            <div class="perinfo">
                <label for="name">ABOUT: </label>
                <textarea type="text" name="" id="about" placeholder="enter your address" class="form-control"></textarea>
            </div>
            <div class="perinfo">
                <label for="email">EMAIL ID: </label>
                <input type="email" name="" id="email" placeholder="enter your email id" class="form-control">
            </div>
            <div class="perinfo">
                <label for="linkdin">LINKDIN ID: </label>
                <input type="email" name="" id="linkdin" placeholder="enter your linkdin id" class="form-control">
            </div>
            <div class="perinfo">
                <label for="dob">NAME: </label>
                <input type="date" name="" id="dob" placeholder="enter your dob" class="form-control">
            </div>
          

            <div class="leftside"></div>
        </div>
        <div class="col no-gutters">
            <h3>PROFESSIONAL INFORMATION</h3>
            <div class="perinfo">
                <label for="work experience">WORKEXPERIENCE : </label>
                <textarea type="text" name="" id="workexp" placeholder="workexperience" class="form-control"></textarea>
            </div>
            <div class="perinfo">
                <label for="skills">SKILLS: </label>
                <textarea type="" name="" id="skills" placeholder="what are your skills" class="form-control"></textarea>
            </div>
            <div class="perinfo">
                <label for="eduq">EDUCATIONAL QUALIFICATION: </label>
                <textarea type="text" name="" id="eduq" placeholder="educational qualification" class="form-control"></textarea>
            </div>
            <div class="perinfo">
                <label for="intrests">INTRESTS : </label>
                <textarea type="text" name="" id="intrests" placeholder="what are your other intrests" class="form-control"></textarea>
            </div>
            <div class="perinfo">
                <label for="intrests"> OTHER INTRESTS : </label>
                <textarea type="text" name="" id="intrests" placeholder="what are your other intrests" class="form-control"></textarea>
            </div>
            <div class="perinfo">
                <label for="intrests"> UPLOAD YOUR PHOTO : </label>
                <textarea type="file" name="" id="intrests" placeholder="upload your photo" class="form-control"></textarea>
            </div>
            
            

            <div class="rightside"></div>
        </div>





    </div>
    
</body>
</html>