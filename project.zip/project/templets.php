<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
   

    <title>templets</title>
  </head>
  <body>
    <h3> CHOOSE THE TEMPLET WHICH SUITS YOUR PROFESSION BEST</h3>
    <h3> based on education, skills, experience</h3>
  
 <div class="first">
    <div class="container">
        <div class="row">
          <div class="col">
            <div class="card" >
              <img src="C:\xampp\htdocs\project\img\picspucs\tem1.jpg" class="card-img-top" alt="...img">
              <div class="card-body">
                <h5 class="card-title">WEB DEVELOPER</h5>
                <p class="card-text">highlights your tech skills</p>
                <a href="filling.php" class="btn btn-primary">get this</a>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card" >
              <img src="C:\xampp\htdocs\project\img\picspucs\tem2.jpg" class="card-img-top" alt="...img">
              <div class="card-body">
                <h5 class="card-title">designer</h5>
                <p class="card-text">concentrates on your designing skills</p>
                <a href="filling.php" class="btn btn-primary">get this</a>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card" >
              <img src="C:\xampp\htdocs\project\img\picspucs\tem3.jpg" class="card-img-top" alt="...img">
              <div class="card-body">
                <h5 class="card-title">engineer</h5>
                <p class="card-text"> !!!!</p>
                <a href="filling.php" class="btn btn-primary">get this</a>
              </div>
            </div>
          </div>
        </div>
      </div>
 </div>
 <div class="second">
    <div class="container">
        <div class="row">
          <div class="col">
            <div class="card" >
              <img src="C:\xampp\htdocs\project\img\picspucs\Screenshot (848).png" class="card-img-top" alt="...img">
              <div class="card-body">
                <h5 class="card-title">interior designing</h5>
                <p class="card-text">this style suits your profession best</p>
                <a href="filling.php" class="btn btn-primary">get this</a>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card" >
              <img src="C:\xampp\htdocs\project\img\picspucs\tem5.jpg" class="card-img-top" alt="...img">
              <div class="card-body">
                <h5 class="card-title">architect</h5>
                <p class="card-text">for people who want to highlight their educatinal skills</p>
                <a href="filling.php" class="btn btn-primary">get this</a>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card" >
              <img src="C:\xampp\htdocs\project\img\picspucs\tem6.jpg" class="card-img-top" alt="...img">
              <div class="card-body">
                <h5 class="card-title">dentist</h5>
                <p class="card-text">this is best for people who have experience</p>
                <a href="filling.php" class="btn btn-primary">get this</a>
              </div>
            </div>
          </div>
        </div>
      </div>
 </div>
 </div>
<div class="container">
<a href="filling.html" class="btn btn-primary">next</a>
<br>
<hr>
<p><a href="welcome.html" class="btn btn-primary">back</a></p>


</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

   
  </body>
</html>